#!/usr/bin/env python
# vim:fileencoding=UTF-8:ts=4:sw=4:sta:et:sts=4:ai

__license__   = 'GPL v3'
__copyright__ = '2023, Jules'
__docformat__ = 'restructuredtext en'

from calibre.customize import InterfaceActionBase

class YomitokuPlugin(InterfaceActionBase):
    '''
    This class is a simple wrapper that provides information about the actual
    plugin class. The actual interface plugin class is called YomitokuPluginAction
    and is defined in the ui.py file, as specified in the actual_plugin field
    below.
    '''
    name                = 'Yomitoku OCR'
    description         = 'Perform OCR on image files using the Yomitoku engine and import the result as an HTML book.'
    supported_platforms = ['windows', 'osx', 'linux']
    author              = 'Jules'
    version             = (0, 1, 0)
    minimum_calibre_version = (5, 0, 0)

    actual_plugin       = 'calibre_plugins.yomitoku_plugin.ui:YomitokuPluginAction'

    def is_customizable(self):
        return True

    def config_widget(self):
        from calibre_plugins.yomitoku_plugin.config import ConfigWidget
        return ConfigWidget()

    def save_settings(self, config_widget):
        config_widget.save_settings()
        ac = self.actual_plugin_
        if ac is not None:
            ac.apply_settings()
