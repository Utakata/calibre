#!/usr/bin/env python
# vim:fileencoding=UTF-8:ts=4:sw=4:sta:et:sts=4:ai

__license__   = 'GPL v3'
__copyright__ = '2023, Jules'
__docformat__ = 'restructuredtext en'

from calibre.gui2.actions import InterfaceAction
from calibre_plugins.yomitoku_plugin.main import MainDialog

class YomitokuPluginAction(InterfaceAction):

    name = 'Yomitoku OCR'

    action_spec = ('Yomitoku OCR', None,
            'Run Yomitoku OCR on an image file', None)

    def genesis(self):
        # icon = get_icons('images/icon.png', 'Yomitoku OCR Plugin')
        # self.qaction.setIcon(icon)
        self.qaction.triggered.connect(self.show_dialog)

    def show_dialog(self):
        base_plugin_object = self.interface_action_base_plugin
        do_user_config = base_plugin_object.do_user_config

        d = MainDialog(self.gui, self.qaction.icon(), do_user_config)
        d.show()

    def apply_settings(self):
        pass
