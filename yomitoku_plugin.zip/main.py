#!/usr/bin/env python
# vim:fileencoding=UTF-8:ts=4:sw=4:sta:et:sts=4:ai

__license__   = 'GPL v3'
__copyright__ = '2023, Jules'
__docformat__ = 'restructuredtext en'

import os
import subprocess
import tempfile

from qt.core import QDialog, QPushButton, QVBoxLayout, QFileDialog, QMessageBox

from calibre.ebooks.metadata.book.base import Metadata
from calibre_plugins.yomitoku_plugin.config import prefs

class MainDialog(QDialog):
    def __init__(self, gui, icon, do_user_config):
        QDialog.__init__(self, gui)
        self.gui = gui
        self.do_user_config = do_user_config

        self.setWindowTitle('Yomitoku OCR')
        # self.setWindowIcon(icon) # Icon will be added later

        layout = QVBoxLayout(self)
        self.setLayout(layout)

        select_button = QPushButton('Select Image Files to OCR', self)
        select_button.clicked.connect(self.select_files)
        layout.addWidget(select_button)

        self.resize(300, 100)

    def select_files(self):
        files, _ = QFileDialog.getOpenFileNames(
            self,
            'Select image files for OCR',
            '', # starting directory
            'Image files (*.jpg *.jpeg *.png *.bmp *.gif);;All files (*)'
        )
        if files:
            self.run_yomitoku(files)
            self.accept() # Close the dialog

    def run_yomitoku(self, image_files):
        yomitoku_path = prefs['yomitoku_path']
        if not yomitoku_path or not os.path.exists(yomitoku_path):
            msg = ('The path to the yomitoku executable is not set or is invalid. '
                   'Please configure it in Preferences -> Plugins -> Yomitoku OCR.')
            QMessageBox.critical(self, 'Yomitoku Not Found', msg)
            return

        for image_path in image_files:
            with tempfile.TemporaryDirectory() as temp_dir:
                try:
                    command = [yomitoku_path, image_path, '-f', 'html', '-o', temp_dir]
                    
                    result = subprocess.run(
                        command, check=True, capture_output=True, text=True, encoding='utf-8'
                    )

                    base_name = os.path.splitext(os.path.basename(image_path))[0]
                    html_file = os.path.join(temp_dir, base_name + '.html')

                    if os.path.exists(html_file):
                        self.add_book_to_calibre(html_file, base_name)
                    else:
                        QMessageBox.warning(self, 'File Not Found', f"Yomitoku ran, but the expected HTML file was not found:\n{html_file}")

                except FileNotFoundError:
                    msg = (f"The yomitoku executable was not found at '{yomitoku_path}'. "
                           "Please ensure the path is correct in the plugin configuration.")
                    QMessageBox.critical(self, 'Yomitoku Not Found', msg)
                    break
                except subprocess.CalledProcessError as e:
                    msg = (f"Yomitoku failed to process {os.path.basename(image_path)}.\n\n"
                           f"Error:\n{e.stderr}")
                    QMessageBox.critical(self, 'Yomitoku Error', msg)
                    continue
    
    def add_book_to_calibre(self, html_path, title):
        try:
            with open(html_path, 'rb') as f:
                mi = Metadata(title)
                db = self.gui.current_db.new_api
                
                # add_books takes a list of tuples: (metadata, {format_name: stream})
                book_ids = db.add_books([(mi, {'HTML': f})])
                
                if book_ids:
                    book_id = book_ids[0]
                    print(f"Successfully added book '{title}' with id {book_id}")
                    # The dialog is already closed, so this message might not be seen if it's tied to the dialog.
                    # A better approach would be a notification in the main calibre window,
                    # but for now, this is sufficient.
                    QMessageBox.information(self.gui, 'Success', f"Successfully created book '{title}'.")
                else:
                    raise Exception("add_books returned no book_id.")

        except Exception as e:
            print(f"Error adding book to Calibre: {e}")
            QMessageBox.critical(self.gui, 'Error Adding Book', f"Failed to add the book '{title}' to the Calibre library.\n\nError: {e}")
